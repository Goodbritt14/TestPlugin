Hello Developers
THis is MY Basic Plugin That i learned to Make 
So For contact Dm me on discord
